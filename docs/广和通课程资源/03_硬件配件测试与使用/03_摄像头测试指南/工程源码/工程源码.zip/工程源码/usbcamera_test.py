import numpy as np
import cv2

ID = 0
while(1):
   cap=cv2.VideoCapture(ID)
   ret,frame =cap.read()
   if ret == False:
   	ID += 1
   else:
      	print(ID)
      	cap.release()
      	break
	
cap = cv2.VideoCapture(ID)
while True:
    sucess,img=cap.read()

    k=cv2.waitKey(3)
    cv2.imwrite("image1.jpg",img)
    imageFn="image1.jpg"
    break




import pyaudio
import wave
import time
import subprocess
def record(time):
    audio_file = 'mylib/aa.wav'
    command1 = ['arecord', '-D', 'plughw:1,0','-r','16000','-d',str(time),audio_file]
    subprocess.run(command1)
    return audio_file
    
record(3)
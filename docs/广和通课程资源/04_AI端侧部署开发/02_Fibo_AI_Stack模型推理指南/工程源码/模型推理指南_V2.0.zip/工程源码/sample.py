from api_infer import *  # Fibo AI推理SDK接口
# ==================== 配置区（用户需修改部分）====================
model_path = "<模型文件路径>"
input_path = "<测试数据输入路径>"
save_path = "<结果保存路径>"
INPUT_NAME = "<模型输入节点名称>"
OUTPUT_NAME = "<模型输出节点名称>"
# ==================== 推理引擎配置字典 ====================
inference_config = {
    'model': model_path,
    'platform': "qualcomm",      
    'framework': "snpe",         
    'runtime': "CPU",        #(e.g., 'CPU', 'GPU', 'DSP', 'NPU'). 
    'log_level': "INFO",    #(e.g., 'trace', 'debug', 'info', 'warn', 'error', 'critical').
    'profile_level': 0,     #0=BALANCED, 1=HIGH_PERFORMANCE, 2=POWER_SAVER, 3=SYSTEM_SETTINGS, 4=SUSTAINED_HIGH_PERFORMANCE, 5=BURST, 6=LOW_POWER_SAVER, 7=HIGH_POWER_SAVER, 8=LOW_BALANCED, 9=EXTREME_POWERSAVER     
}
# 创建推理会话，初始化推理引擎
inference_session = InferenceSession(**inference_config)
assert inference_session.Initialize() == 0, "推理引擎初始化失败"
# 执行预处理
input_data = preprocess(input_path)
# 准备输入数据
input_feed = {INPUT_NAME: input_data}
# 输出层名称列表（空列表表示获取所有输出）
output_names = [OUTPUT_NAME] if OUTPUT_NAME else []
# 执行推理，返回包含输出结果的字典
outputs = inference_session.Execute(output_names, input_feed)
# 执行后处理
result = postprocess(outputs, save_path)
# ==================== 释放资源 ====================
assert inference_session.Release() == 0, "资源释放失败"
print("推理完成")
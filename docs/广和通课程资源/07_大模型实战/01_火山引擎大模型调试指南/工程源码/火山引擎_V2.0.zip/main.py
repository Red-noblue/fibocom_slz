from openai import OpenAI
import time
import json
import os
import sys
from datetime import datetime
import readline  # 用于命令行历史记录
import argparse  # 用于命令行参数解析
import configparser  # 用于配置文件解析

#####################配置区域 - 此区域配置优先级最高####################


# API配置
api_key = "your_api_key_here"  # 在此处填入您的火山引擎API密钥
base_url = "https://ai-gateway.vei.volces.com/v1"
model = "doubao-1.5-lite-32k"

# 对话参数配置
DEFAULT_SYSTEM_PROMPT = "You are a helpful and knowledgeable assistant."
DEFAULT_MAX_TOKENS = 3000
DEFAULT_TEMPERATURE = 0.7
DEFAULT_STREAM_OUTPUT = True  # 是否启用流式输出

# 文件路径配置
CONFIG_FILE_PATH = "config.ini"  # 配置文件路径
CONVERSATION_SAVE_DIR = "conversations"  # 对话保存目录

# 界面配置
ENABLE_COLOR_OUTPUT = True  # 是否启用彩色输出
PROMPT_COLOR = "\033[94m"   # 提示符颜色 (蓝色)
RESET_COLOR = "\033[0m"     # 重置颜色

######################配置区域结束 - 以下为程序代码####################


class ConfigManager:
    """配置管理器类 - 代码默认配置优先级最高"""
    
    def __init__(self, config_file_path=CONFIG_FILE_PATH):
        self.config_file_path = config_file_path
        self.config = configparser.ConfigParser()
        # 先加载配置文件，但之后会被代码默认值覆盖
        self.load_config()
    
    def load_config(self):
        """加载配置文件"""
        if os.path.exists(self.config_file_path):
            try:
                self.config.read(self.config_file_path)
                print(f"已加载配置文件: {self.config_file_path}")
            except Exception as e:
                print(f"加载配置文件时出错: {e}")
        else:
            print("未找到配置文件，使用代码默认设置")
            self.create_default_config()
    
    def create_default_config(self):
        """创建默认配置文件（仅作为参考，实际运行以代码配置为准）"""
        self.config['API'] = {
            'api_key': api_key,
            'base_url': base_url,
            'model': model
        }
        
        self.config['DIALOG'] = {
            'system_prompt': DEFAULT_SYSTEM_PROMPT,
            'max_tokens': str(DEFAULT_MAX_TOKENS),
            'temperature': str(DEFAULT_TEMPERATURE),
            'stream_output': str(DEFAULT_STREAM_OUTPUT)
        }
        
        self.config['UI'] = {
            'enable_color_output': str(ENABLE_COLOR_OUTPUT),
            'prompt_color': PROMPT_COLOR
        }
        
        self.config['PATHS'] = {
            'conversation_save_dir': CONVERSATION_SAVE_DIR
        }
        
        self.save_config()
    
    def save_config(self):
        """保存配置文件"""
        try:
            with open(self.config_file_path, 'w') as configfile:
                self.config.write(configfile)
            print(f"配置文件已保存: {self.config_file_path}")
        except Exception as e:
            print(f"保存配置文件时出错: {e}")
    
    def get_api_key(self):
        """获取API密钥 """
        return api_key  # 直接返回代码中的默认值
    
    def get_base_url(self):
        """获取基础URL"""
        return base_url  # 直接返回代码中的默认值
    
    def get_model(self):
        """获取默认模型  """
        return model  # 直接返回代码中的默认值
    
    def get_system_prompt(self):
        """获取系统提示  """
        return DEFAULT_SYSTEM_PROMPT  # 直接返回代码中的默认值
    
    def get_max_tokens(self):
        """获取最大token数  """
        return DEFAULT_MAX_TOKENS  # 直接返回代码中的默认值
    
    def get_temperature(self):
        """获取温度参数  """
        return DEFAULT_TEMPERATURE  # 直接返回代码中的默认值
    
    def get_stream_output(self):
        """获取流式输出设置  """
        return DEFAULT_STREAM_OUTPUT  # 直接返回代码中的默认值
    
    def get_conversation_save_dir(self):
        """获取对话保存目录  """
        return CONVERSATION_SAVE_DIR  # 直接返回代码中的默认值
    
    def get_enable_color_output(self):
        """获取是否启用彩色输出  """
        return ENABLE_COLOR_OUTPUT  # 直接返回代码中的默认值
    
    def get_prompt_color(self):
        """获取提示符颜色  """
        return PROMPT_COLOR  # 直接返回代码中的默认值
    
    def update_setting(self, section, key, value):
        """更新配置设置（仅影响配置文件，不影响代码默认值）"""
        if not self.config.has_section(section):
            self.config.add_section(section)
        self.config.set(section, key, str(value))
        self.save_config()


class VolcanoAIChat:
    """火山引擎AI对话助手类"""
    
    def __init__(self, config_manager):
        self.config = config_manager
        
        # 获取配置（现在这些配置将始终来自代码中的默认值）
        api_key = self.config.get_api_key()
        base_url = self.config.get_base_url()
        model = self.config.get_model()
        
        # 验证API密钥
        if not api_key or api_key == "your_api_key_here":
            raise ValueError("请提供有效的API密钥。请编辑代码中的配置区域设置API密钥。")
        
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.conversation_history = []
        self.conversation_start_time = None
        self.conversation_file = None
        
        # 确保对话保存目录存在
        save_dir = self.config.get_conversation_save_dir()
        os.makedirs(save_dir, exist_ok=True)
        
        # 初始化客户端
        self._init_client()
    
    def _init_client(self):
        """初始化OpenAI客户端"""
        try:
            self.client = OpenAI(base_url=self.base_url, api_key=self.api_key)
            print("API客户端初始化成功")
        except Exception as e:
            raise Exception(f"API客户端初始化失败: {e}")
    
    def start_conversation(self, system_prompt=None):
        """开始新的对话"""
        if system_prompt is None:
            system_prompt = self.config.get_system_prompt()
            
        self.conversation_history = [{"role": "system", "content": system_prompt}]
        self.conversation_start_time = datetime.now()
        self.conversation_file = None
        
        # 使用彩色输出
        prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
        reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
        
        print(f"{prompt_color}新对话已开始 - {self.conversation_start_time.strftime('%Y-%m-%d %H:%M:%S')}{reset_color}")
        print(f"{prompt_color}系统提示: {system_prompt}{reset_color}")
        print(f"{prompt_color}当前模型: {self.model}{reset_color}")
        print("-" * 50)
    
    def add_message(self, role, content):
        """添加消息到对话历史"""
        self.conversation_history.append({"role": role, "content": content})
    
    def get_response(self, user_input, max_tokens=None, temperature=None, stream=None):
        """获取AI回复"""
        # 使用配置的默认值
        if max_tokens is None:
            max_tokens = self.config.get_max_tokens()
        if temperature is None:
            temperature = self.config.get_temperature()
        if stream is None:
            stream = self.config.get_stream_output()
        
        # 添加用户消息到历史
        self.add_message("user", user_input)
        
        try:
            # 记录开始时间
            start_time = time.time()
            
            # 调用API
            if stream:
                # 流式输出
                response_text = ""
                
                # 使用彩色输出
                prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
                reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
                
                print(f"{prompt_color}AI: {reset_color}", end="", flush=True)
                
                stream_response = self.client.chat.completions.create(
                    model=self.model,
                    messages=self.conversation_history,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    stream=True
                )
                
                for chunk in stream_response:
                    # 检查chunk是否有choices属性且不为空
                    if hasattr(chunk, 'choices') and chunk.choices and len(chunk.choices) > 0:
                        # 检查delta是否有content属性
                        if hasattr(chunk.choices[0], 'delta') and hasattr(chunk.choices[0].delta, 'content') and chunk.choices[0].delta.content is not None:
                            content = chunk.choices[0].delta.content
                            print(content, end="", flush=True)
                            response_text += content
                
                print()  # 换行
                ai_response = response_text
                usage = None  # 流式响应不包含使用量信息
            else:
                # 非流式输出
                completion = self.client.chat.completions.create(
                    model=self.model,
                    messages=self.conversation_history,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                
                # 检查completion是否有choices属性且不为空
                if hasattr(completion, 'choices') and completion.choices and len(completion.choices) > 0:
                    ai_response = completion.choices[0].message.content
                    usage = completion.usage if hasattr(completion, 'usage') else None
                else:
                    raise Exception("API响应中没有有效的内容")
            
            # 计算响应时间
            response_time = time.time() - start_time
            
            # 检查响应是否为空
            if not ai_response or ai_response.strip() == "":
                raise Exception("API返回了空响应")
            
            # 添加AI回复到历史
            self.add_message("assistant", ai_response)
            
            return ai_response, response_time, usage
            
        except Exception as e:
            # 如果出错，移除最后一条用户消息
            if self.conversation_history and self.conversation_history[-1].get("role") == "user":
                self.conversation_history.pop()
            raise e
    
    def show_conversation_stats(self):
        """显示对话统计信息"""
        if self.conversation_start_time:
            duration = datetime.now() - self.conversation_start_time
            hours, remainder = divmod(duration.total_seconds(), 3600)
            minutes, seconds = divmod(remainder, 60)
            
            # 使用彩色输出
            prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
            reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
            
            print(f"{prompt_color}\n对话统计:{reset_color}")
            print(f"{prompt_color}- 开始时间: {self.conversation_start_time.strftime('%Y-%m-%d %H:%M:%S')}{reset_color}")
            print(f"{prompt_color}- 持续时间: {int(hours)}小时 {int(minutes)}分钟 {int(seconds)}秒{reset_color}")
            print(f"{prompt_color}- 消息数量: {len(self.conversation_history) - 1}{reset_color}")  # 减去系统消息
            print(f"{prompt_color}- 当前模型: {self.model}{reset_color}")
            
            if self.conversation_file:
                print(f"{prompt_color}- 保存文件: {self.conversation_file}{reset_color}")
    
    def save_conversation(self, filename=None):
        """保存对话历史到文件"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"conversation_{timestamp}.json"
        
        # 添加保存目录路径
        save_dir = self.config.get_conversation_save_dir()
        filename = os.path.join(save_dir, filename)
        
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(filename) if os.path.dirname(filename) else '.', exist_ok=True)
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump({
                    "model": self.model,
                    "start_time": self.conversation_start_time.strftime('%Y-%m-%d %H:%M:%S') if self.conversation_start_time else None,
                    "messages": self.conversation_history
                }, f, ensure_ascii=False, indent=2)
            
            self.conversation_file = filename
            
            # 使用彩色输出
            prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
            reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
            
            print(f"{prompt_color}对话已保存到: {filename}{reset_color}")
            return filename
        except Exception as e:
            print(f"保存对话时出错: {e}")
            return None
    
    def load_conversation(self, filename):
        """从文件加载对话历史"""
        # 添加保存目录路径
        save_dir = self.config.get_conversation_save_dir()
        filename = os.path.join(save_dir, filename)
        
        try:
            if not os.path.exists(filename):
                print(f"文件不存在: {filename}")
                return False
                
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.model = data.get("model", self.model)
                self.conversation_history = data.get("messages", [])
                
                # 尝试解析开始时间
                start_time_str = data.get("start_time")
                if start_time_str:
                    try:
                        self.conversation_start_time = datetime.strptime(start_time_str, '%Y-%m-%d %H:%M:%S')
                    except:
                        self.conversation_start_time = None
                
                self.conversation_file = filename
                
                # 使用彩色输出
                prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
                reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
                
                print(f"{prompt_color}对话已从 {filename} 加载{reset_color}")
                print(f"{prompt_color}模型: {self.model}{reset_color}")
                print(f"{prompt_color}消息数量: {len(self.conversation_history) - 1}{reset_color}")
                
                # 显示最后几条消息
                if len(self.conversation_history) > 1:
                    print(f"{prompt_color}\n最后几条消息:{reset_color}")
                    for msg in self.conversation_history[-min(3, len(self.conversation_history)):]:
                        role = msg.get("role", "unknown")
                        content = msg.get("content", "")[:100] + "..." if len(msg.get("content", "")) > 100 else msg.get("content", "")
                        print(f"{prompt_color}{role.upper()}: {content}{reset_color}")
                
                return True
                
        except Exception as e:
            print(f"加载对话时出错: {e}")
            return False
    
    def print_conversation_history(self, limit=None):
        """打印对话历史"""
        if len(self.conversation_history) <= 1:
            print("对话历史为空")
            return
        
        # 使用彩色输出
        prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
        reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
            
        print(f"{prompt_color}\n对话历史 (共 {len(self.conversation_history) - 1} 条消息):{reset_color}")
        print("-" * 60)
        
        messages_to_show = self.conversation_history[1:]  # 跳过系统消息
        if limit:
            messages_to_show = messages_to_show[-limit:]
        
        for i, msg in enumerate(messages_to_show, 1):
            role = msg.get("role", "unknown").upper()
            content = msg.get("content", "")
            
            # 格式化输出
            if role == "USER":
                print(f"{prompt_color}\n[{i}] 您: {content}{reset_color}")
            else:
                print(f"{prompt_color}\n[{i}] AI: {content}{reset_color}")
    
    def change_model(self, new_model):
        """更改模型"""
        old_model = self.model
        self.model = new_model
        
        # 使用彩色输出
        prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
        reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
        
        print(f"{prompt_color}模型已从 {old_model} 更改为 {new_model}{reset_color}")
    
    def export_conversation(self, filename=None, format="txt"):
        """导出对话为不同格式"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"conversation_{timestamp}.{format}"
        
        # 添加保存目录路径
        save_dir = self.config.get_conversation_save_dir()
        filename = os.path.join(save_dir, filename)
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                if format == "txt":
                    f.write(f"对话导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"使用模型: {self.model}\n")
                    f.write("-" * 60 + "\n\n")
                    
                    for msg in self.conversation_history[1:]:  # 跳过系统消息
                        role = "您" if msg.get("role") == "user" else "AI"
                        f.write(f"{role}: {msg.get('content', '')}\n\n")
                
                elif format == "md":
                    f.write(f"# 对话记录\n\n")
                    f.write(f"- 导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"- 使用模型: {self.model}\n\n")
                    
                    for msg in self.conversation_history[1:]:  # 跳过系统消息
                        role = "**您**" if msg.get("role") == "user" else "**AI**"
                        f.write(f"{role}: {msg.get('content', '')}\n\n")
                
                else:
                    print(f"不支持的导出格式: {format}")
                    return False
            
            # 使用彩色输出
            prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
            reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
            
            print(f"{prompt_color}对话已导出为 {format.upper()} 格式: {filename}{reset_color}")
            return True
            
        except Exception as e:
            print(f"导出对话时出错: {e}")
            return False
    
    def clear_history(self, keep_system=True):
        """清空对话历史但保留系统提示"""
        if keep_system and self.conversation_history:
            system_prompt = self.conversation_history[0]
            self.conversation_history = [system_prompt]
        else:
            self.conversation_history = []
        
        # 使用彩色输出
        prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
        reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
        
        print(f"{prompt_color}对话历史已清空{reset_color}")
    
    def get_models(self):
        """获取可用模型列表"""
        try:
            models = self.client.models.list()
            if hasattr(models, 'data') and models.data:
                return [model.id for model in models.data]
            else:
                print("API返回的模型列表为空")
                return []
        except Exception as e:
            print(f"获取模型列表失败: {e}")
            return []
    
    def show_config(self):
        """显示当前配置（现在始终显示代码中的默认值）"""
        prompt_color = self.config.get_prompt_color() if self.config.get_enable_color_output() else ""
        reset_color = RESET_COLOR if self.config.get_enable_color_output() else ""
        
        print(f"{prompt_color}\n当前配置 (代码配置区域优先级最高):{reset_color}")
        print(f"{prompt_color}- API密钥: {self.api_key[:10]}...{self.api_key[-5:] if len(self.api_key) > 15 else ''}{reset_color}")
        print(f"{prompt_color}- 基础URL: {self.base_url}{reset_color}")
        print(f"{prompt_color}- 默认模型: {self.model}{reset_color}")
        print(f"{prompt_color}- 系统提示: {self.config.get_system_prompt()[:50]}...{reset_color}")
        print(f"{prompt_color}- 最大token数: {self.config.get_max_tokens()}{reset_color}")
        print(f"{prompt_color}- 温度参数: {self.config.get_temperature()}{reset_color}")
        print(f"{prompt_color}- 流式输出: {'启用' if self.config.get_stream_output() else '禁用'}{reset_color}")
        print(f"{prompt_color}- 对话保存目录: {self.config.get_conversation_save_dir()}{reset_color}")
        print(f"{prompt_color}- 彩色输出: {'启用' if self.config.get_enable_color_output() else '禁用'}{reset_color}")


def list_conversation_files(config_manager):
    """列出当前目录下的对话文件"""
    save_dir = config_manager.get_conversation_save_dir()
    conversation_files = []
    
    if os.path.exists(save_dir):
        for file in os.listdir(save_dir):
            if file.startswith("conversation_") and (file.endswith(".json") or file.endswith(".txt") or file.endswith(".md")):
                conversation_files.append(file)
    
    return sorted(conversation_files, reverse=True)  # 按时间倒序排列


def print_help(config_manager):
    """打印帮助信息"""
    prompt_color = config_manager.get_prompt_color() if config_manager.get_enable_color_output() else ""
    reset_color = RESET_COLOR if config_manager.get_enable_color_output() else ""
    
    print(f"{prompt_color}\n可用命令:{reset_color}")
    print(f"{prompt_color}  /help          - 显示此帮助信息{reset_color}")
    print(f"{prompt_color}  /history [n]   - 显示对话历史（可指定显示最近n条）{reset_color}")
    print(f"{prompt_color}  /save [name]   - 保存对话到文件（可指定文件名）{reset_color}")
    print(f"{prompt_color}  /load <name>   - 从文件加载对话{reset_color}")
    print(f"{prompt_color}  /list          - 列出所有对话文件{reset_color}")
    print(f"{prompt_color}  /stats         - 显示对话统计{reset_color}")
    print(f"{prompt_color}  /model <name>  - 更改模型{reset_color}")
    print(f"{prompt_color}  /models        - 显示可用模型列表{reset_color}")
    print(f"{prompt_color}  /config        - 显示当前配置{reset_color}")
    print(f"{prompt_color}  /clear         - 开始新对话（清空历史）{reset_color}")
    print(f"{prompt_color}  /export [fmt]  - 导出对话为文本格式（txt/md）{reset_color}")
    print(f"{prompt_color}  /stream on/off - 开启/关闭流式输出{reset_color}")
    print(f"{prompt_color}  /quit          - 退出程序{reset_color}")
    print(f"{prompt_color}\n提示: 输入内容与AI对话，空行重新显示提示符{reset_color}")


def parse_arguments():
    """解析命令行参数（这些参数现在不会覆盖代码配置）"""
    parser = argparse.ArgumentParser(description='火山引擎AI对话助手 - 代码配置区域优先级最高')
    parser.add_argument('--api-key', help='API密钥（不会覆盖代码配置）', default=None)
    parser.add_argument('--model', help='模型名称（不会覆盖代码配置）', default=None)
    parser.add_argument('--base-url', help='API基础URL（不会覆盖代码配置）', default=None)
    parser.add_argument('--system-prompt', help='系统提示（不会覆盖代码配置）', default=None)
    parser.add_argument('--max-tokens', type=int, help='最大token数（不会覆盖代码配置）', default=None)
    parser.add_argument('--temperature', type=float, help='温度参数（不会覆盖代码配置）', default=None)
    parser.add_argument('--stream', type=lambda x: (str(x).lower() in ['true', '1', 'yes', 'on']), 
                        help='是否启用流式输出（不会覆盖代码配置）', default=None)
    parser.add_argument('--load', help='加载对话文件', default=None)
    parser.add_argument('--config', help='配置文件路径', default=CONFIG_FILE_PATH)
    parser.add_argument('--no-color', action='store_true', help='禁用彩色输出（不会覆盖代码配置）', default=False)
    return parser.parse_args()


def main():
    # 解析命令行参数
    args = parse_arguments()
    
    # 初始化配置管理器（现在使用代码配置作为最高优先级）
    config_manager = ConfigManager(config_file_path=args.config)
    
    try:
        # 初始化聊天助手
        chat = VolcanoAIChat(config_manager)
        
        # 如果有加载文件的参数，尝试加载
        if args.load:
            if not chat.load_conversation(args.load):
                print(f"无法加载文件: {args.load}")
        
        # 开始新对话
        system_prompt = config_manager.get_system_prompt()
        chat.start_conversation(system_prompt)
        
        # 显示当前配置
        chat.show_config()
        
        print_help(config_manager)
        print("-" * 50)
        
        # 配置
        stream_output = config_manager.get_stream_output()
        
        while True:
            try:
                # 使用彩色提示符
                prompt_color = config_manager.get_prompt_color() if config_manager.get_enable_color_output() else ""
                reset_color = RESET_COLOR if config_manager.get_enable_color_output() else ""
                
                user_input = input(f"{prompt_color}\n您: {reset_color}").strip()
                
                if not user_input:
                    print(f"{prompt_color}输入 /help 查看可用命令{reset_color}")
                    continue
                    
                # 处理命令
                if user_input.startswith('/'):
                    command_parts = user_input[1:].split()
                    command = command_parts[0].lower() if command_parts else ""
                    args_list = command_parts[1:] if len(command_parts) > 1 else []
                    
                    if command == 'quit' or command == 'exit':
                        # 退出前询问是否保存
                        save = input(f"{prompt_color}退出前是否保存对话? (y/N): {reset_color}").strip().lower()
                        if save == 'y' or save == 'yes':
                            chat.save_conversation()
                        print(f"{prompt_color}感谢使用，再见!{reset_color}")
                        break
                        
                    elif command == 'help':
                        print_help(config_manager)
                        
                    elif command == 'history':
                        limit = int(args_list[0]) if args_list and args_list[0].isdigit() else 10
                        chat.print_conversation_history(limit=limit)
                        
                    elif command == 'save':
                        filename = args_list[0] if args_list else None
                        chat.save_conversation(filename)
                        
                    elif command == 'load':
                        if not args_list:
                            print(f"{prompt_color}请指定要加载的文件名{reset_color}")
                            files = list_conversation_files(config_manager)
                            if files:
                                print(f"{prompt_color}可用文件:{reset_color}")
                                for i, file in enumerate(files, 1):
                                    print(f"{prompt_color}  {i}. {file}{reset_color}")
                        else:
                            chat.load_conversation(args_list[0])
                        
                    elif command == 'list':
                        files = list_conversation_files(config_manager)
                        if files:
                            print(f"{prompt_color}可用的对话文件:{reset_color}")
                            for i, file in enumerate(files, 1):
                                print(f"{prompt_color}  {i}. {file}{reset_color}")
                        else:
                            print(f"{prompt_color}没有找到对话文件{reset_color}")
                        
                    elif command == 'stats':
                        chat.show_conversation_stats()
                        
                    elif command == 'model':
                        if not args_list:
                            print(f"{prompt_color}请指定模型名称{reset_color}")
                        else:
                            chat.change_model(args_list[0])
                    
                    elif command == 'models':
                        models = chat.get_models()
                        if models:
                            print(f"{prompt_color}可用模型:{reset_color}")
                            for model in models:
                                print(f"{prompt_color}  - {model}{reset_color}")
                        else:
                            print(f"{prompt_color}无法获取模型列表或列表为空{reset_color}")
                    
                    elif command == 'config':
                        chat.show_config()
                        
                    elif command == 'clear':
                        chat.start_conversation()
                        print(f"{prompt_color}已开始新对话{reset_color}")
                        
                    elif command == 'export':
                        format = args_list[0] if args_list else "txt"
                        if format not in ["txt", "md"]:
                            print(f"{prompt_color}支持的格式: txt, md{reset_color}")
                        else:
                            chat.export_conversation(format=format)
                    
                    elif command == 'stream':
                        if not args_list:
                            status = "开启" if stream_output else "关闭"
                            print(f"{prompt_color}当前流式输出状态: {status}{reset_color}")
                        elif args_list[0] in ["on", "yes", "true", "1"]:
                            stream_output = True
                            print(f"{prompt_color}流式输出已开启（本次会话有效，重启后恢复代码配置）{reset_color}")
                        elif args_list[0] in ["off", "no", "false", "0"]:
                            stream_output = False
                            print(f"{prompt_color}流式输出已关闭（本次会话有效，重启后恢复代码配置）{reset_color}")
                        else:
                            print(f"{prompt_color}参数错误，使用: /stream on 或 /stream off{reset_color}")
                        
                    else:
                        print(f"{prompt_color}未知命令。输入 /help 查看可用命令{reset_color}")
                        
                    continue
                
                # 获取AI回复
                try:
                    response, response_time, usage = chat.get_response(
                        user_input, 
                        stream=stream_output
                    )
                    
                    # 如果不是流式输出，打印回复和性能信息
                    if not stream_output:
                        print(f"{prompt_color}AI: {response}{reset_color}")
                        print(f"{prompt_color}\n[响应时间: {response_time:.2f}s", end="")
                        if usage:
                            print(f", Tokens: {usage.prompt_tokens}(输入)+{usage.completion_tokens}(输出)={usage.total_tokens}(总计)", end="")
                        print(f"]{reset_color}")
                        
                except Exception as e:
                    print(f"{prompt_color}\n请求发生错误: {e}{reset_color}")
                    print(f"{prompt_color}请检查您的网络连接和API密钥后重试{reset_color}")
                
            except KeyboardInterrupt:
                print(f"{prompt_color}\n\n中断请求，输入/quit退出程序{reset_color}")
                
            except EOFError:
                print(f"{prompt_color}\n\n检测到文件结束符，退出程序{reset_color}")
                break
                
    except Exception as e:
        print(f"初始化失败: {e}")
        print("请检查您的API密钥和网络连接")


if __name__ == "__main__":
    main()